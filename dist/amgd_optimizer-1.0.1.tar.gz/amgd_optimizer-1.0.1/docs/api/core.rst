Core Module
===========

.. automodule:: amgd.core
   :members:

AMGD Optimizer
--------------

.. autoclass:: amgd.core.AMGDOptimizer
   :members:
   :special-members: __init__

Base Classes
------------

.. automodule:: amgd.core.base
   :members: