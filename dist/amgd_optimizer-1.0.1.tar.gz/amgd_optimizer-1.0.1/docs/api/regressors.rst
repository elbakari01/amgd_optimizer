Regressors Module
=================

.. automodule:: amgd.regressors
   :members:

AMGD Poisson Regressor
----------------------

.. autoclass:: amgd.regressors.AMGDPoissonRegressor
   :members:
   :special-members: __init__